package testCases;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;

import com.google.common.base.Function;

import Factories.BrowserFactory;
import Factories.DataProviderFactory;




public class BaseTest 
{
	public static WebDriver driver;
	
	
	//---------------------function for adding the particular element------------------//
	
	public void enterData(WebElement element,String txt)
	{
		try
		{
			element.sendKeys(txt);
		}
		catch(Exception e)
		{
			System.out.println(e);
			
		}
	}
	
	
	//---------------------function for clicking the particular element------------------//
	
	public void clickElement(WebElement element)
	{
		
			element.click();
	}
	
	//---------------------function for delay------------------//
	
	protected void waitForSeconds(double d)
	{
		try {
			Thread.sleep((long) (d*1000));
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public boolean waitForElementToBeVisible(WebElement element,int time)
	{
		

		FluentWait<WebDriver> wait = new FluentWait<WebDriver>(driver)
		 
		    .withTimeout(time, TimeUnit.SECONDS)
		 
		    .pollingEvery(5, TimeUnit.SECONDS)
		 
		    .ignoring(NoSuchElementException.class);
		 
		Boolean isVisible = wait.until(new Function<WebDriver, Boolean>() 
		{
		  public Boolean apply(WebDriver driver) {
		    if(element.isDisplayed())
		    {
			  return true;
		    }
		    else
		    {
		    	return false;
		    }
		}
		});
		return isVisible;
		}
	

	
	public void waitForElementToBeClickable(WebElement element)
	{

		WebDriverWait wait = new WebDriverWait(driver, 40);
		 wait.until(ExpectedConditions.elementToBeClickable(element));
	}
	
	
	
	
	
	
	//---------------------functions for validation------------------//
	
	public boolean validateContainsText(WebElement element,String text)
	{
		if(element.getText().contains(text))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	public boolean validateLabel(WebElement e,String label)
	{
		if(e.getText().trim().equalsIgnoreCase(label))
		{
			
			return true;
		}
		else
		{
			return false;
		}
	}
	public boolean validateInnerText(WebElement element,String text)
	{
		if(element.getAttribute("textContent").equalsIgnoreCase(text))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	
	public boolean elementDisplayed(WebElement element)
	{
		if(element.isDisplayed())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	
	public boolean elementExist(List<WebElement> element)
	{
		if(element.isEmpty())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
			
  public boolean validateElementNotExist(WebElement e)
	{
		try
		{
			e.getText();
			return true;
		}
		catch(Exception exp)
		{
			return false;
		}
	}
		
	
  public boolean validateEnterTxt(WebElement element,String date)
	{
		try
		{
	     if(element.getAttribute("value").equalsIgnoreCase(date))
	     {
	    	 return true;
	     }
	     return false;
		}
		catch(Exception e)
		{
			System.out.println(e);
			return false;
		} 
	}
	
	
	//---------------------function for Element whether it is enable or not(Editable or not)------------------//
	
	public boolean checkDisableElement(WebElement ee )
	{
		try {
		   if(ee.getAttribute("disabled")!=null)
		   {
			   return true;
		   }
		   else if(ee.getAttribute("aria-disabled").equalsIgnoreCase("true"))
		   {
			   return true;
		   }
		return false;
		}

	catch(Exception e1)
		{
		return false;
		}
	}


	
	
	//---------------------function for checking for the Session------------------//
	
	public void endTheSession()
	{
		try
		{
			
			driver.navigate().refresh();
			new WebDriverWait(driver, 10).until(ExpectedConditions.alertIsPresent());
			driver.switchTo().alert().accept();
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	public void refreshPage(WebElement element)
	{
		try
		{
			
			element.sendKeys(Keys.F5);
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	//---------------------function for switching to Second Window------------------//
	
	public void switchToSecondWindow(WebDriver driver) 
	{
		Set<String> handles = driver.getWindowHandles();
		 
		String firstWinHandle = driver.getWindowHandle(); 
		
		String secondWinHandle;
		 
		handles.remove(firstWinHandle);
		 
		String winHandle=(String) handles.iterator().next();
		 
		if (winHandle!=firstWinHandle){
		 
			//To retrieve the handle of second window, extracting the handle which does not match to first window handle
			 
			secondWinHandle=winHandle; //Storing handle of second window handle
			 
			//Switch control to new window
			 
			driver.switchTo().window(secondWinHandle);
		}
	}
	
	//---------------------function for Delete the Text from the particular Element ------------------//
	
	public void deleteTxt(WebElement element)
	{
		try
		{
			element.sendKeys(Keys.BACK_SPACE);
		}
		catch(Exception e)
		{
			System.out.println(e);
			
		}
	}
	
	//---------------------function for clearing the text of the particular Element------------------//
	
	public void clearField(WebElement element)
	{
		try
		{
			element.clear();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	//---------------------function for get Focus on the particular Element ------------------//

	public void getFocus(WebElement element)
	{
		try
		{
		//new Actions(driver).moveToElement(element).click().perform();
			element.sendKeys("");
		}catch(Exception e1){
			System.out.println("Unable to get focus");
			e1.printStackTrace();
		}
	}
	
	//---------------------function for Scrolling down the focus to the particular Element------------------//
	
	public void keysDown(WebElement element)
	{
		try{
			element.sendKeys(Keys.ARROW_DOWN);
			}catch(Exception e1){
				System.out.println(e1);
			System.out.println("Unable to click element");
			e1.printStackTrace();
		} 
	}

public boolean validateDropDownSelectedValue(WebElement e,String expected )
{
	Select dropDown=new Select(e);
	
	
	if(dropDown.getFirstSelectedOption().getText().equalsIgnoreCase(expected))
	{
		return true;
	}
	else
	{
		return false;
	}



}


public void switchToFrame(int num)
{
	driver.switchTo().frame(num);
}

public void waitForPageLoad()
{
	WebDriverWait wait = new WebDriverWait(driver, 100);
    wait.until(new ExpectedCondition<Boolean>() {
	public Boolean apply(WebDriver wdriver) {
	return ((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete");
	}
	});
}

public boolean waitForPageLoadTime()
{    
	Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
			 
		    .withTimeout(250, TimeUnit.SECONDS)
		 
		    .pollingEvery(1, TimeUnit.SECONDS)
		 
		    .ignoring(NoSuchElementException.class);
		 
		Boolean isVisible = wait.until(new Function<WebDriver, Boolean>() 
		{
		  public Boolean apply(WebDriver driver) {
		    if(((JavascriptExecutor) driver).executeScript("return document.readyState").toString().equals("complete"))
		    {
			  return true;
		    }
		    else
		    {
		    	return false;
		    }
		}
		});
		return isVisible;
		
		}
public WebElement checkFocus()
{
	return driver.switchTo().activeElement();
}

}