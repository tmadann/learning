package Factories;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.firefox.internal.ProfilesIni;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import testCases.BaseTest;

/*
 * This class can do the following"
 * - To create required Webdriver
 * - To maintain an instance of a Webdriver
 */
public class BrowserFactory extends BaseTest
{
	public WebDriver getBrowser(String browserName)
	{
		if (browserName.equals("Firefox"))
		{
		  if (driver == null)
		{
			
			  System.setProperty("webdriver.gecko.driver", "D://geckodriver-v0.19.1-win64//geckodriver.exe");
			  driver = new FirefoxDriver();
				
		}
		  else
		  {
			  return driver;
		  }
		}
			else if (browserName.equals("Chrome"))
			{
				if (driver == null)
				{
				System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"//src//exe//chromedriver.exe");
				driver = new ChromeDriver();
				
			    }
				else
				{
					return driver;
				}
			}
			long pageLoadTimeOut = DataProviderFactory.getConfigurationDataProvider().getPageLoadTimeOut();
			long implicitWait = DataProviderFactory.getConfigurationDataProvider().getImplicitWait();
		    
			driver.manage().timeouts().pageLoadTimeout(pageLoadTimeOut, TimeUnit.SECONDS);
		    driver.manage().timeouts().implicitlyWait(implicitWait, TimeUnit.SECONDS);   
		    driver.manage().window().maximize();
		    return driver;
		  }
			
	   
	
public static WebDriver getBrowser()
	{
		return driver;
	}
	
	public static void closeWebDriver()		
		{		
		driver.quit();
		}

}
