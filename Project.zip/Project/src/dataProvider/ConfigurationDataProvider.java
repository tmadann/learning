package dataProvider;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

/*
 * This class reads the data from config.properties
 */
public class ConfigurationDataProvider 
{
	Properties propertyFile;
	String fileName;
	
	public ConfigurationDataProvider(String propertyFilePath) throws IOException
	{
		this.fileName = propertyFilePath;
		BufferedReader reader = new BufferedReader(new FileReader(fileName));
		propertyFile = new Properties();
		propertyFile.load(reader);
		reader.close();
	}
	
	public String getReportBrowserName()
	{
		return propertyFile.getProperty("browserType");
	}
	
	public String getBaseURL()
	{
		return propertyFile.getProperty("baseURL");
	}
		
	public long getPageLoadTimeOut()
	{
		return Long.parseLong(propertyFile.getProperty("pageLoadTimeOut"));
	}
	
	public long getImplicitWait()
	{
		return Long.parseLong(propertyFile.getProperty("implicitWait"));
	}
	
	public String getIEServerPath()
	{
		return propertyFile.getProperty("IEServerPath");
	}
	
	public String getChromeServerPath()
	{
		return propertyFile.getProperty("ChromeServerPath");
	}
	
	public String getScreenShotFolder()
	{
		return propertyFile.getProperty("screenShotFolder");
	}
	
	public String getDataBaseHost()
	{
		return propertyFile.getProperty("host");
	}
	
	public String getDataBaseUsername()
	{
		return propertyFile.getProperty("username");
	}
	
	public String getDataBasePassword()
	{
		return propertyFile.getProperty("password");
	}

}
