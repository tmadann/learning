package pageObjects;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import org.openqa.selenium.WebDriver;



public class BasePage 
{	
	
	public static WebDriver driver;
	
	public BasePage(WebDriver driver)
	{
		this.driver = driver;
		
	}
	
	
	public Logger printLog(Class className){
		
		Logger log = Logger.getLogger(className);
		if(log == null){
		PropertyConfigurator.configure(System.getProperty("user.dir")+"\\src\\log4j.properties");
		
	}
		return log;
	}
	Logger log = printLog(BasePage.class);
	
	
	
}
